"use client";

import { useParams } from "next/navigation";
import useGet from "@/app/(hooks)/useGet";
import { UnitsList } from "./(components)/UnitsList";

export default function UnitsPage() {
  const { chapterid } = useParams();

  const { data } = useGet(`lesson/${chapterid}`, ["get_units", chapterid]);

  return <UnitsList initialUnits={data ?? []} />;
}
