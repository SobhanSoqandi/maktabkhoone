"use client";

import { useParams } from "next/navigation";
import useGet from "@/app/(hooks)/useGet";
import { LectureForm } from "./(components)/LectureForm";

export default function UnitEditPage() {
  const { unitId } = useParams();
  const isNew = unitId === "new";

  const { data, isPending } = useGet(`lesson/${unitId}`, ["get_unit", unitId], {
    enabled: !isNew,
  });

  if (!isNew && isPending) {
    return <p className="py-10 text-center text-sm text-slate-500">در حال بارگذاری...</p>;
  }

  return <LectureForm unit={isNew ? undefined : data} />;
}
