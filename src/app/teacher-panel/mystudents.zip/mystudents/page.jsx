import MyStudentCard from "./(components)/MyStudentCard";
import MyStudents from "./mystudentsdata";

function Page() {
  return (
    <div className="p-6 space-y-5">

      <div>
        <h2 className="text-xl font-bold text-gray-800">
          دانش‌آموزان من
        </h2>
        <p className="text-sm text-gray-400 mt-2">
          لیست تمام دانش‌آموزان ثبت‌شده
        </p>
      </div>

      <div className="flex flex-col gap-3">
        {MyStudents.map((student) => (
          <MyStudentCard
            key={student.id}
            student={student}
          />
        ))}
      </div>

    </div>
  );
}

export default Page;